package com.dicoding.courseschedule.util

enum class TimePicker {
    START_TIME,
    END_TIME
}