package com.example.cisnuxprime.presentation.ui.components

import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.cisnuxprime.presentation.ui.theme.md_theme_placeholder

@Composable
fun MovieCardPlaceholder(modifier: Modifier = Modifier) {
    Surface(
        color = md_theme_placeholder,
        content = {},
        modifier = modifier,
    )
}