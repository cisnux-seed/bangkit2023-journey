package com.example.cisnuxprime.presentation.utils

import androidx.compose.runtime.Immutable
import androidx.core.net.toUri
import dev.cisnux.core.utils.FAVORITE_URI
import dev.cisnux.core.utils.HOME_URI

// compose utils
@Immutable
sealed class AppDestination(val route: String) {
    object HomeRoute : AppDestination(route = "home") {
        val deepLinkPattern = "$HOME_URI/${HomeRoute.route}"
    }

    object FavoriteRoute : AppDestination(route = "favorites") {
        val deepLinkPattern = "$FAVORITE_URI/${FavoriteRoute.route}"
    }

    object SplashRoute : AppDestination(route = "splash")
    object MovieDetailRoute : AppDestination(route = "movies/{id}?isDynamic={isDynamic}") {
        val deepLinkPattern = "$HOME_URI/${MovieDetailRoute.route}"
        fun createDeepLink(id: Int, isDynamic: Boolean = false) =
            "$HOME_URI/movies/$id?isDynamic=$isDynamic".toUri()
    }
}