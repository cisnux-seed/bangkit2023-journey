package com.example.cisnuxprime.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.cisnuxprime.presentation.ui.theme.CisnuxPrimeTheme
import com.example.cisnuxprime.presentation.navigation.PrimeAppNavGraph
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CisnuxPrimeTheme {
                PrimeAppNavGraph()
            }
        }
    }
}
