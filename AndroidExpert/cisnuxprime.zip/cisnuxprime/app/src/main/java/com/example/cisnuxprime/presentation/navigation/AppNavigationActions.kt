package com.example.cisnuxprime.presentation.navigation

import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.net.toUri
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import com.example.cisnuxprime.presentation.utils.AppDestination
import kotlin.reflect.KClass

class AppNavigationActions(
    navController: NavHostController,
    context: Context,
) {
    val navigateToMovieDetail: (
        id: Int,
    ) -> Unit = { id ->
        navController.navigate(route = "movies/$id")
    }
    val navigateUp: () -> Unit = {
        navController.navigateUp()
    }
    val navigateToHomeForSplash: () -> Unit = {
        navController.navigate(AppDestination.HomeRoute.route) {
            popUpTo(AppDestination.SplashRoute.route) {
                inclusive = true
            }
            launchSingleTop = true
        }
    }
    val navigateToMovieDetailForDeeplink: (id: Int, isDynamic: Boolean, cls: KClass<*>) -> Unit =
        { id, isDynamic, cls ->
            val deepLinkIntent = Intent(
                Intent.ACTION_VIEW,
                AppDestination.MovieDetailRoute
                    .createDeepLink(id = id, isDynamic = isDynamic),
                context,
                cls.java
            )
            val deepLinkPendingIntent: PendingIntent? =
                TaskStackBuilder.create(context).run {
                    addNextIntentWithParentStack(deepLinkIntent)
                    getPendingIntent(
                        REQUEST_CODE,
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE
                        else PendingIntent.FLAG_UPDATE_CURRENT
                    )
                }
            deepLinkPendingIntent?.send()
        }
    val navigateToHomeForDynamicModule: () -> Unit = {
        navController.navigate(AppDestination.HomeRoute.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                inclusive = true
            }
            launchSingleTop = true
        }
    }
    val navigateForBottomNav: (destination: AppDestination, currentRoute: AppDestination) -> Unit =
        { destination, currentRoute ->
            if (destination.route != currentRoute.route)
                when (destination) {
                    AppDestination.HomeRoute -> {
                        val deepLinkIntent = Intent(
                            Intent.ACTION_VIEW
                        ).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                            data = AppDestination.HomeRoute.deepLinkPattern.toUri()
                        }
                        context.startActivity(deepLinkIntent)
                    }

                    AppDestination.FavoriteRoute -> {
                        val deepLinkIntent = Intent(
                            Intent.ACTION_VIEW
                        ).apply {
                            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                            data = AppDestination.FavoriteRoute.deepLinkPattern.toUri()
                        }
                        context.startActivity(deepLinkIntent)
                    }

                    else -> {
                        navController.navigate(destination.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            restoreState = true
                            launchSingleTop = true
                        }
                    }
                }
        }

    private companion object{
        const val REQUEST_CODE = 239
    }
}

@Composable
fun rememberNavigationActions(
    navController: NavHostController,
    context: Context = LocalContext.current
): AppNavigationActions =
    remember(navController) {
        AppNavigationActions(navController = navController, context = context)
    }