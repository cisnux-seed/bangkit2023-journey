package com.example.cisnuxprime.presentation.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandIn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.example.cisnuxprime.presentation.detail.MovieDetailScreen
import com.example.cisnuxprime.presentation.home.HomeScreen
import com.example.cisnuxprime.presentation.splash.SplashScreen
import com.example.cisnuxprime.presentation.utils.AppDestination

@Composable
fun PrimeAppNavGraph(
    navController: NavHostController = rememberNavController(),
    navigationActions: AppNavigationActions = rememberNavigationActions(navController = navController)
) {
    NavHost(
        navController = navController,
        startDestination = AppDestination.SplashRoute.route
    ) {
        composable(
            route = AppDestination.SplashRoute.route,
            enterTransition = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            popExitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(durationMillis = 700)
                )
            }
        ) {
            SplashScreen(navigateToHome = navigationActions.navigateToHomeForSplash)
        }
        composable(
            route = AppDestination.HomeRoute.route,
            deepLinks = listOf(navDeepLink {
                uriPattern = AppDestination.HomeRoute.deepLinkPattern
            }),
            enterTransition = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            popEnterTransition = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            popExitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(durationMillis = 700)
                )
            }
        ) {
            HomeScreen(
                navigateToMovieDetail = navigationActions.navigateToMovieDetail,
                navigateForBottomNav = navigationActions.navigateForBottomNav
            )
        }
        composable(
            route = AppDestination.MovieDetailRoute.route,
            arguments = listOf(
                navArgument(name = "id") {
                    nullable = false
                    type = NavType.IntType
                },
                navArgument(name = "isDynamic") {
                    nullable = false
                    defaultValue = false
                    type = NavType.BoolType
                }
            ),
            deepLinks = listOf(navDeepLink {
                uriPattern = AppDestination.MovieDetailRoute.deepLinkPattern
            }),
            enterTransition = {
                expandIn(
                    expandFrom = Alignment.CenterStart,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            popEnterTransition = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            popExitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(durationMillis = 700)
                )
            }
        ) { backStackEntry ->
            val isDynamic = backStackEntry.arguments!!.getBoolean("isDynamic")
            MovieDetailScreen(
                navigateUp = if (!isDynamic) navigationActions.navigateUp
                else navigationActions.navigateToHomeForDynamicModule,
                navigateToMovieDetail = navigationActions.navigateToMovieDetail,
            )
        }
    }
}