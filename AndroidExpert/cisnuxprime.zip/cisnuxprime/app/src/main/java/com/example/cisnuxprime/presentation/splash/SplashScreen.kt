package com.example.cisnuxprime.presentation.splash

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import com.example.cisnuxprime.R
import com.example.cisnuxprime.presentation.ui.theme.CisnuxPrimeTheme
import com.example.cisnuxprime.presentation.utils.SplashWaitTimeMillis
import kotlinx.coroutines.delay

@Preview(showBackground = true)
@Composable
private fun SplashScreenPreview() {
    CisnuxPrimeTheme {
        SplashScreen(navigateToHome = { /*TODO*/ })
    }
}

@Composable
fun SplashScreen(
    navigateToHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val composition by rememberLottieComposition(spec = LottieCompositionSpec.RawRes(resId = R.raw.splash_screen))
    val onNavigation by rememberUpdatedState(navigateToHome)

    LaunchedEffect(Unit) {
        delay(SplashWaitTimeMillis)
        onNavigation()
    }

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) {
        LottieAnimation(
            composition = composition,
            iterations = LottieConstants.IterateForever,
            modifier = modifier
        )
    }
}
