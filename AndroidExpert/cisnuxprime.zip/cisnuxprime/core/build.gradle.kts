val arrowCore: String by project
val ktorVersion: String by project
val hilt: String by project
val pagingVersion: String by project
val slf4j: String by project
val roomVersion: String by project

plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")
    kotlin("plugin.serialization")
    kotlin("kapt")
}

android {
    namespace = "dev.cisnux.core"
    compileSdk = 33

    defaultConfig {
        buildConfigField(
            "String", "TMDB_TOKEN",
            "\"eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5MzdkOTgzZmVlOWYxOWJmYTYzMmI5ZDRlNDY0Y2Q0MCIsInN1YiI6IjYxNmY4ODk1MTA4OWJhMDA5NWY3MGZjMyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.Gpx0qxCx__XpqgjOl3NJje3Mn0jhGx83Hxz6eTaEzmo\""
        )
        minSdk = 21
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        buildConfig = true
    }
}

dependencies {
    // hilt
    implementation("com.google.dagger:hilt-android:$hilt")
    kapt("com.google.dagger:hilt-compiler:$hilt")

    // ktor
    implementation("io.ktor:ktor-client-core:$ktorVersion")
    implementation("io.ktor:ktor-client-cio:$ktorVersion")
    debugImplementation("org.slf4j:slf4j-simple:$slf4j")
    implementation("io.ktor:ktor-client-logging:$ktorVersion")
    implementation("io.ktor:ktor-client-content-negotiation:$ktorVersion")
    implementation("io.ktor:ktor-serialization-kotlinx-json:$ktorVersion")

    // room
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-paging:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")

    // paging
    implementation("androidx.paging:paging-runtime-ktx:$pagingVersion")

    // monad
    implementation("io.arrow-kt:arrow-core:$arrowCore")
}

kapt {
    correctErrorTypes = true
}