package dev.cisnux.core.domain.repositories

import androidx.paging.PagingData
import dev.cisnux.core.utils.MovieCategory
import dev.cisnux.core.utils.UiState
import dev.cisnux.core.domain.models.Movie
import dev.cisnux.core.domain.models.MovieDetail
import kotlinx.coroutines.flow.Flow

interface MovieRepository {
    fun getMoviesByCategory(category: MovieCategory): Flow<PagingData<Movie>>
    fun getMovieById(movieId: Int): Flow<UiState<MovieDetail>>
    fun getRecommendationMovies(movieId: Int): Flow<PagingData<Movie>>
    fun getMoviesByQuery(query: String): Flow<PagingData<Movie>>
    suspend fun upsertFavoriteMovie(movie: MovieDetail)
    fun getFavoriteMovies(): Flow<List<Movie>>
}