package dev.cisnux.core.utils

const val BASE_IMAGE_URL = "https://image.tmdb.org/t/p/original"
const val MOVIE_TABLE = "movie"
const val REMOTE_KEY_TABLE = "movie_remote_key"
const val CISNUX_PRIME_DB = "cisnux_prime"
const val BASE_URL_MOVIE = "https://api.themoviedb.org/3"
const val FAVORITE_URI = "favorite://cisnuxprime"
const val HOME_URI = "home://cisnuxprime"