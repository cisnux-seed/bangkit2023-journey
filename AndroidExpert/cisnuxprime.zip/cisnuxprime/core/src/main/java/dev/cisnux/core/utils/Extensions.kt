package dev.cisnux.core.utils

import androidx.paging.PagingData
import androidx.paging.filter
import androidx.paging.map
import dev.cisnux.core.data.sources.locals.databases.MovieEntity
import dev.cisnux.core.data.sources.remotes.responses.MovieResponseItem
import dev.cisnux.core.domain.models.MovieDetail
import dev.cisnux.core.domain.models.Movie

fun MovieDetail.asMovieEntity() =
    MovieEntity(
        id = id,
        title = title,
        poster = poster,
        voteAverage = voteAverage,
        isFavorite = isFavorite,
        overview = overview,
        movieCategory = movieCategory,
        nowPlayingPage = nowPlayingPage,
        popularPage = popularPage,
        topRatedPage = topRatedPage
    )

fun List<MovieEntity>.fromListMovieEntities() = map {
    Movie(
        id = it.id,
        title = it.title,
        poster = it.poster,
        voteAverage = it.voteAverage,
        overview = it.overview
    )
}

fun PagingData<MovieEntity>.fromPagingMovieEntities() = map {
    Movie(
        id = it.id,
        title = it.title,
        poster = it.poster,
        voteAverage = it.voteAverage,
        overview = it.overview
    )
}

fun PagingData<MovieResponseItem>.fromPagingMovieResponseItem() =
    filter { it.posterPath != null && it.overview?.isNotBlank() == true }
        .map {
            Movie(
                id = it.id,
                title = it.title,
                poster = it.posterPath!!.toPosterUrl(),
                voteAverage = it.voteAverage,
                overview = it.overview!!
            )
        }

fun String.toPosterUrl() = "$BASE_IMAGE_URL/$this"

fun Int.duration(): String {
    val hours = this / 60
    val minutes = this % 60

    return if (hours > 0)
        "${hours}h ${minutes}m"
    else "${minutes}m"
}
