package dev.cisnux.core.utils

import io.ktor.http.HttpStatusCode

sealed class Failure(override var message: String?) : Exception(message) {
    class ConnectionFailure(
        message: String = "😞No internet connection",
    ) : Failure(message)

    class NotFoundFailure(
        message: String? = null,
    ) : Failure(message)

    class ServerFailure(
        message: String? = null,
    ) : Failure(message)

    class BadRequestFailure(
        message: String? = null,
    ) : Failure(message)

    class UnauthorizedFailure(
        message: String? = null,
    ) : Failure(message)

    companion object {
        val HTTP_FAILURES = mapOf(
            HttpStatusCode.BadRequest to BadRequestFailure(),
            HttpStatusCode.Unauthorized to UnauthorizedFailure(),
            HttpStatusCode.NotFound to NotFoundFailure(),
            HttpStatusCode.InternalServerError to ServerFailure()
        )
    }
}


