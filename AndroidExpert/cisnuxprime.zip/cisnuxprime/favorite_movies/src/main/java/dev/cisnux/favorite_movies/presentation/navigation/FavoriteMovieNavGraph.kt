package dev.cisnux.favorite_movies.presentation.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navDeepLink
import com.example.cisnuxprime.presentation.MainActivity
import com.example.cisnuxprime.presentation.navigation.AppNavigationActions
import com.example.cisnuxprime.presentation.navigation.rememberNavigationActions
import com.example.cisnuxprime.presentation.utils.AppDestination
import dev.cisnux.favorite_movies.presentation.favorite.FavoriteMovieScreen

@Composable
fun FavoriteMovieNavGraph(
    navController: NavHostController = rememberNavController(),
    navigationActions: AppNavigationActions = rememberNavigationActions(navController = navController),
    factory: ViewModelProvider.Factory,
) {
    NavHost(
        navController = navController,
        startDestination = AppDestination.FavoriteRoute.route
    ) {
        composable(
            route = AppDestination.FavoriteRoute.route,
            deepLinks = listOf(navDeepLink {
                uriPattern = AppDestination.FavoriteRoute.deepLinkPattern
            }),
            enterTransition = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            exitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Left,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            popEnterTransition = {
                slideIntoContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(durationMillis = 700)
                )
            },
            popExitTransition = {
                slideOutOfContainer(
                    towards = AnimatedContentTransitionScope.SlideDirection.Right,
                    animationSpec = tween(durationMillis = 700)
                )
            }
        ) {
            FavoriteMovieScreen(
                navigateToMovieDetail = { id ->
                    navigationActions.navigateToMovieDetailForDeeplink(
                        id,
                        true,
                        MainActivity::class
                    )
                },
                navigateForBottomNav = navigationActions.navigateForBottomNav,
                favoriteMovieViewModel = viewModel(factory = factory)
            )
        }
    }
}