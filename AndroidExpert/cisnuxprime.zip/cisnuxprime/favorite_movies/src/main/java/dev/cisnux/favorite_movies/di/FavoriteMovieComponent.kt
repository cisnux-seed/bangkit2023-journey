package dev.cisnux.favorite_movies.di

import android.content.Context
import dagger.BindsInstance
import dagger.Component
import dev.cisnux.core.di.FavoriteModuleDependencies
import dev.cisnux.favorite_movies.presentation.FavoriteMovieActivity
import javax.inject.Singleton

@Component(
    dependencies = [FavoriteModuleDependencies::class],
    modules = [FavoriteViewModelModule::class]
)
@Singleton
interface FavoriteMovieComponent {
    fun inject(activity: FavoriteMovieActivity)

    @Component.Builder
    interface Builder {
        fun context(@BindsInstance context: Context): Builder
        fun appDependencies(favoriteModuleDependencies: FavoriteModuleDependencies): Builder
        fun build(): FavoriteMovieComponent
    }
}