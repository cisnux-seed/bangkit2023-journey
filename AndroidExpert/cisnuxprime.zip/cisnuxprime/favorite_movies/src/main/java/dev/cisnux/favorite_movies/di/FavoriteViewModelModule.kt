package dev.cisnux.favorite_movies.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent
import dagger.multibindings.IntoMap
import dev.cisnux.core.factory.ViewModelFactory
import dev.cisnux.favorite_movies.presentation.favorite.FavoriteMovieViewModel

@Module
@InstallIn(ViewModelComponent::class)
abstract class FavoriteViewModelModule {
    @Binds
    abstract fun bindViewModelFactory(factory: ViewModelFactory): ViewModelProvider.Factory

    @Binds
    @IntoMap
    @FavoriteViewModelKey(FavoriteMovieViewModel::class)
    abstract fun bindFavoriteMovieViewModel(viewModel: FavoriteMovieViewModel): ViewModel
}