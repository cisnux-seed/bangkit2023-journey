package dev.cisnux.favorite_movies.presentation.favorite

import androidx.lifecycle.ViewModel
import dev.cisnux.core.domain.usecases.MovieInteractor
import javax.inject.Inject

class FavoriteMovieViewModel @Inject constructor(
    useCase: MovieInteractor
): ViewModel() {
    val favoriteMovies = useCase.getFavoriteMovies()
}
