package dev.cisnux.favorite_movies.presentation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import com.example.cisnuxprime.presentation.ui.theme.CisnuxPrimeTheme
import dagger.hilt.android.EntryPointAccessors
import dev.cisnux.core.di.FavoriteModuleDependencies
import dev.cisnux.favorite_movies.di.DaggerFavoriteMovieComponent
import dev.cisnux.favorite_movies.presentation.navigation.FavoriteMovieNavGraph
import javax.inject.Inject

class FavoriteMovieActivity : ComponentActivity() {
    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override fun onCreate(savedInstanceState: Bundle?) {
        DaggerFavoriteMovieComponent
            .builder()
            .context(this)
            .appDependencies(
                EntryPointAccessors.fromApplication(
                    applicationContext,
                    FavoriteModuleDependencies::class.java
                )
            )
            .build()
            .inject(this)

        super.onCreate(savedInstanceState)
        setContent {
            CisnuxPrimeTheme {
                FavoriteMovieNavGraph(factory = viewModelFactory)
            }
        }
    }
}